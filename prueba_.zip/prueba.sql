DROP DATABASE prueba;
----------------------------------------------------------------
--base de datos llamada prueba
----------------------------------------------------------------
CREATE DATABASE prueba;
----------------------------------------------------------------
--Crear tabla cliente
----------------------------------------------------------------
CREATE TABLE cliente(id_cliente SERIAL NOT NULL,
nombre_cliente VARCHAR(255),
rut_cliente VARCHAR(15),
direccion_cliente VARCHAR(255),
PRIMARY KEY(id_cliente));
----------------------------------------------------------------
--Crear tabla factura
----------------------------------------------------------------
CREATE TABLE factura(num_factura SERIAL NOT NULL,
id_cliente INT,
fecha_factura DATE,
FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente),
PRIMARY KEY(num_factura));
----------------------------------------------------------------
--Crear tabla totales_venta
----------------------------------------------------------------
CREATE TABLE totales_venta(id_totales SERIAL NOT NULL,
num_factura INT,
sub_total INT,
iva_factura INT,
precio_total INT,
FOREIGN KEY (num_factura) REFERENCES factura(num_factura),
PRIMARY KEY(id_totales));
----------------------------------------------------------------
--Crear tabla categoria
----------------------------------------------------------------
CREATE TABLE categoria(id_categoria SERIAL NOT NULL,
nombre_categoria VARCHAR(255),
descripcion_categoria VARCHAR(255),
PRIMARY KEY(id_categoria));
----------------------------------------------------------------
--Crear tabla producto
----------------------------------------------------------------
CREATE TABLE producto(id_producto SERIAL NOT NULL,
id_categoria INT,
nombre_producto VARCHAR(255),
stock_producto INT,
precio_unitario INT, 
FOREIGN KEY (id_categoria) REFERENCES categoria(id_categoria),
PRIMARY KEY(id_producto));
----------------------------------------------------------------
--Crear tabla factura_producto
----------------------------------------------------------------
CREATE TABLE fact_prod(id_fact_prod SERIAL NOT NULL,
num_factura INT,
id_producto INT,
cantidad INT,
precio INT,
FOREIGN KEY (num_factura) REFERENCES factura(num_factura),
FOREIGN KEY (id_producto) REFERENCES producto(id_producto),
PRIMARY KEY(id_fact_prod));
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
--INSERT 5 CLIENTES
-----------------------------------------------------------------------------------
INSERT INTO cliente(nombre_cliente,rut_cliente,direccion_cliente) VALUES 
('ALEJANDRO MEZA','17318147-7','PEÑALOLEN');
INSERT INTO cliente(nombre_cliente,rut_cliente,direccion_cliente) VALUES 
('XIMENA TORRES','5318451-K','LAS CONDES');
INSERT INTO cliente(nombre_cliente,rut_cliente,direccion_cliente) VALUES 
('MACARENA CUADROS','16802635-K','CONCHALI');
INSERT INTO cliente(nombre_cliente,rut_cliente,direccion_cliente) VALUES 
('JORGE FLORES','19445635-8','MACUL');
INSERT INTO cliente(nombre_cliente,rut_cliente,direccion_cliente) VALUES 
('CLAUDIO MEDEL','15582456-0','PROVIDENCIA');
-----------------------------------------------------------------------------------
--INSERT 3 CATEGORIA
-----------------------------------------------------------------------------------
INSERT INTO categoria(nombre_categoria,descripcion_categoria) VALUES 
('LACTEOS','MANTENER LOS PRODUCTOS A BAJA TEMPERATURA');
INSERT INTO categoria(nombre_categoria,descripcion_categoria) VALUES 
('VERDURAS','MANTENER LOS PRODUCTOS EN UN LUGAR FRESCO');
INSERT INTO categoria(nombre_categoria,descripcion_categoria) VALUES 
('PASTELERIA','MANTENER LOS PRODUCTOS REFRIGERADOS');
-----------------------------------------------------------------------------------
--INSERT 8 PRODUCTOS
-----------------------------------------------------------------------------------
INSERT INTO producto(id_categoria,nombre_producto,stock_producto,precio_unitario) VALUES 
(1,'YOGURT',200,350);
INSERT INTO producto(id_categoria,nombre_producto,stock_producto,precio_unitario) VALUES 
(1,'PANACOTA',150,480);
INSERT INTO producto(id_categoria,nombre_producto,stock_producto,precio_unitario) VALUES 
(1,'1+1',100,600);
INSERT INTO producto(id_categoria,nombre_producto,stock_producto,precio_unitario) VALUES 
(2,'PIMENTON',50,300);
INSERT INTO producto(id_categoria,nombre_producto,stock_producto,precio_unitario) VALUES 
(2,'LECHUGA',30,500);
INSERT INTO producto(id_categoria,nombre_producto,stock_producto,precio_unitario) VALUES 
(2,'AJI',100,00);
INSERT INTO producto(id_categoria,nombre_producto,stock_producto,precio_unitario) VALUES 
(3,'TORTA',30,9990);
INSERT INTO producto(id_categoria,nombre_producto,stock_producto,precio_unitario) VALUES 
(3,'QUEQUE',50,5000);
-----------------------------------------------------------------------------------
--INSERT FACTURAS -- 2 para el cliente 1, con 2 y 3 productos
-----------------------------------------------------------------------------------
INSERT INTO factura(id_cliente,fecha_factura) VALUES (1,'04-10-2020');
INSERT INTO factura(id_cliente,fecha_factura) VALUES (1,'06-10-2020');

INSERT INTO fact_prod(num_factura,id_producto,cantidad,precio) VALUES (1,3,1,600);
INSERT INTO fact_prod(num_factura,id_producto,cantidad,precio) VALUES (1,1,1,350);
INSERT INTO fact_prod(num_factura,id_producto,cantidad,precio) VALUES (2,7,1,9990);
INSERT INTO fact_prod(num_factura,id_producto,cantidad,precio) VALUES (2,1,1,350);
INSERT INTO fact_prod(num_factura,id_producto,cantidad,precio) VALUES (2,8,1,5000);

INSERT INTO totales_venta(num_factura,sub_total,iva_factura,precio_total) VALUES (1,950,19,1130);
INSERT INTO totales_venta(num_factura,sub_total,iva_factura,precio_total) VALUES (2,15340,19,18255);
-----------------------------------------------------------------------------------
--INSERT FACTURAS -- 3 para el cliente 2, con 3, 2 y 3 productos
-----------------------------------------------------------------------------------
INSERT INTO factura(id_cliente,fecha_factura) VALUES (2,'02-10-2020');--3 factura
INSERT INTO factura(id_cliente,fecha_factura) VALUES (2,'22-08-2020');--4
INSERT INTO factura(id_cliente,fecha_factura) VALUES (2,'02-06-2020');--5

INSERT INTO fact_prod(num_factura,id_producto,cantidad,precio) VALUES (3,2,3,1440);
INSERT INTO fact_prod(num_factura,id_producto,cantidad,precio) VALUES (4,7,2,19980);
INSERT INTO fact_prod(num_factura,id_producto,cantidad,precio) VALUES (5,5,3,1200);

INSERT INTO totales_venta(num_factura,sub_total,iva_factura,precio_total) VALUES (3,1440,19,1714);
INSERT INTO totales_venta(num_factura,sub_total,iva_factura,precio_total) VALUES (4,19980,19,23776);
INSERT INTO totales_venta(num_factura,sub_total,iva_factura,precio_total) VALUES (5,1200,19,1428);
-----------------------------------------------------------------------------------
--INSERT FACTURAS -- 1 para el cliente 3, con 1 producto
-----------------------------------------------------------------------------------
INSERT INTO factura(id_cliente,fecha_factura) VALUES (3,'12-10-2020');--6 factura

INSERT INTO fact_prod(num_factura,id_producto,cantidad,precio) VALUES (6,4,1,300);

INSERT INTO totales_venta(num_factura,sub_total,iva_factura,precio_total) VALUES (6,300,19,357);
-----------------------------------------------------------------------------------
--INSERT FACTURAS -- 4 para el cliente 4, con 2, 3, 4 y 1 producto
-----------------------------------------------------------------------------------
INSERT INTO factura(id_cliente,fecha_factura) VALUES (4,'22-11-2020');--7 factura
INSERT INTO factura(id_cliente,fecha_factura) VALUES (4,'15-12-2020');--8 factura
INSERT INTO factura(id_cliente,fecha_factura) VALUES (4,'09-09-2020');--9 factura
INSERT INTO factura(id_cliente,fecha_factura) VALUES (4,'12-01-2020');--10 factura

INSERT INTO fact_prod(num_factura,id_producto,cantidad,precio) VALUES (7,4,1,300);
INSERT INTO fact_prod(num_factura,id_producto,cantidad,precio) VALUES (7,8,1,9990);
INSERT INTO fact_prod(num_factura,id_producto,cantidad,precio) VALUES (8,1,2,700);
INSERT INTO fact_prod(num_factura,id_producto,cantidad,precio) VALUES (8,8,1,5000);
INSERT INTO fact_prod(num_factura,id_producto,cantidad,precio) VALUES (9,5,4,2000);
INSERT INTO fact_prod(num_factura,id_producto,cantidad,precio) VALUES (10,3,1,600);

INSERT INTO totales_venta(num_factura,sub_total,iva_factura,precio_total) VALUES (7,10290,19,12245);
INSERT INTO totales_venta(num_factura,sub_total,iva_factura,precio_total) VALUES (8,5700,19,6783);
INSERT INTO totales_venta(num_factura,sub_total,iva_factura,precio_total) VALUES (9,2000,19,2380);
INSERT INTO totales_venta(num_factura,sub_total,iva_factura,precio_total) VALUES (10,600,19,714);
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
--SELECT ¿Que cliente realizó la compra más cara?
-----------------------------------------------------------------------------------

SELECT cliente.nombre_cliente,totales_venta.precio_total AS COMPRA_MAS_CARA
FROM cliente
INNER JOIN factura ON cliente.id_cliente = factura.id_cliente
INNER JOIN totales_venta ON factura.num_factura = totales_venta.num_factura
order by totales_venta.precio_total DESC limit 1;

---------------------------------------------------------------------------------
--¿Que cliente pagó sobre 100 de monto?
---------------------------------------------------------------------------------

SELECT cliente.nombre_cliente,totales_venta.precio_total AS CLIENTE_MAYOR_100
FROM cliente
INNER JOIN factura ON cliente.id_cliente = factura.id_cliente
INNER JOIN totales_venta ON factura.num_factura = totales_venta.num_factura
WHERE totales_venta.precio_total > 100;


---------------------------------------------------------------------------------
--¿Cuantos clientes han comprado el producto 6
---------------------------------------------------------------------------------

SELECT count(cliente.nombre_cliente) AS PRODUCTO_6_COMPRADO
FROM cliente
INNER JOIN factura ON cliente.id_cliente = factura.id_cliente
INNER JOIN fact_prod ON factura.num_factura = fact_prod.num_factura
WHERE fact_prod.id_producto = 6;


